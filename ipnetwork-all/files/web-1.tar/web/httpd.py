#!/usr/bin/python

import CGIHTTPServer
CGIHTTPServer.test()

