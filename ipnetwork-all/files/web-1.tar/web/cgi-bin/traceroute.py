#!/usr/bin/env python
# -*- coding: utf-8 -*-

import cgi
import os
import sys
import subprocess


print """
<!DOCTYPE html>
<html lang="jp">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bootstrap Template</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body>
<div class="container">
  <h1>Traceroute web service</h1>
  <h4>経路の非対称性を確認しよう！</h4> </br></br>


  <form action="" method="post"> 
  Hostname or IP address </br>
  <input type="text" name="ipaddr" value="" placeholder="e.g. www.google.com "> 
  </br></br>

  No lookup option </br>
  Yes <input type="radio" name="nolookup" value="yes"> 
  No <input type="radio" name="nolookup" value="no" checked> 
  </br></br>

  <button type="submit" class="btn btn-default">Execute!</button>
  </form> </br>

"""


form = cgi.FieldStorage()
if not form.has_key("ipaddr"):
    print 'Please set a hostname or an IP address to tracetoure'
else:
    ipaddr = form['ipaddr'].value
    command = []
    command.append('traceroute')
    if form['nolookup'].value == 'yes':
        command.append('-n')

    command.append(ipaddr)
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()

    print '</br>'
    print '<h4><i>command :'
    for i in range(len(command)):
        sys.stdout.write(command[i]+' ')
    print '</i></h4></br>'
    print '<h4>RESULT</h4>'

    print p[0].replace('\n', '</br>')
    print p[1].replace('\n', '</br>')

print """
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
"""
