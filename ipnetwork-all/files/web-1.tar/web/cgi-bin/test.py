#!/usr/bin/env python

print "Content-type: text/html\n"
print "<html><body>Python is awesome !</body></html>"
